set FLASK_APP=<filename>.py
$env:FLASK_APP = "<filename>.py"
python -m flask run

Credits - https://github.com/sauravkdubey/Web_Manipulator 

Script modified to work on Windows. 
